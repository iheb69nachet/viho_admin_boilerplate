<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Inscription\\Providers\\InscriptionServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Inscription\\Providers\\InscriptionServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);