<?php

return [
    'name' => 'Translation'
];
