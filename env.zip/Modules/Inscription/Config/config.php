<?php

return [
    'name' => 'Inscription'
];
